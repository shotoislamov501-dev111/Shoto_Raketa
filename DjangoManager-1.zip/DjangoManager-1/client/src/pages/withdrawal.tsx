import Layout from "@/components/layout";
import { INITIAL_USER } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wallet, CreditCard, AlertTriangle, QrCode, Check, X, Smartphone } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/lib/language-context";

interface SavedCard {
  id: string;
  last4: string;
  brand: string;
  expiryDate: string;
}

const BANKS = [
  { id: "tinkoff", name: "Tinkoff", color: "blue", ru: "Тинькофф" },
  { id: "sber", name: "Sberbank", color: "green", ru: "Сбербанк" },
  { id: "alpha", name: "Alfa-Bank", color: "red", ru: "Альфа-Банк" },
  { id: "vtb", name: "VTB", color: "blue", ru: "ВТБ" },
  { id: "raiffeisen", name: "Raiffeisen", color: "purple", ru: "Райффайзен" },
];

export default function WithdrawalPage() {
  const user = INITIAL_USER;
  const { language } = useLanguage();
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"tinkoff" | "card" | "phone">("tinkoff");
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [showNewCardForm, setShowNewCardForm] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("+7");
  const [selectedBank, setSelectedBank] = useState("tinkoff");
  const [cards, setCards] = useState<SavedCard[]>([
    { id: "card_1", last4: "4242", brand: "Visa", expiryDate: "12/25" },
  ]);
  const [newCard, setNewCard] = useState({
    cardNumber: "",
    cardHolder: "",
    expiryDate: "",
    cvv: "",
  });

  const TINKOFF_PHONE = "+79047275294";

  const handleWithdraw = async () => {
    if (!amount) {
      alert(language === 'ru' ? "Введите сумму" : "Enter amount");
      return;
    }

    if (paymentMethod === "card" && !selectedCard) {
      alert(language === 'ru' ? "Выберите карту" : "Select a card");
      return;
    }

    if (paymentMethod === "phone" && (!phoneNumber || phoneNumber.length < 11)) {
      alert(language === 'ru' ? "Введите корректный номер телефона" : "Enter a valid phone number");
      return;
    }

    const numAmount = parseFloat(amount);
    if (numAmount < 100) {
      alert(language === 'ru' ? "Минимум вывода ₽100" : "Minimum withdrawal ₽100");
      return;
    }

    if (numAmount > user.balance) {
      alert(language === 'ru' ? "Недостаточно средств" : "Insufficient balance");
      return;
    }

    setLoading(true);
    try {
      const fee = numAmount * 0.01;
      const finalAmount = (numAmount * 0.99).toFixed(2);
      
      const response = await fetch("/api/withdrawals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          amount: numAmount,
          fee: fee,
          status: "pending",
        }),
      });

      if (response.ok) {
        if (paymentMethod === "tinkoff") {
          alert(
            language === 'ru'
              ? `Заявка на вывод ₽${finalAmount} создана. Переводим на ${TINKOFF_PHONE}\nПоступит за 1-3 рабочих дня`
              : `Withdrawal request for ₽${finalAmount} created. Sending to ${TINKOFF_PHONE}\nWill arrive in 1-3 business days`
          );
        } else if (paymentMethod === "phone") {
          alert(
            language === 'ru'
              ? `Заявка на вывод ₽${finalAmount} на номер ${phoneNumber} создана\nПоступит за 1-3 рабочих дня`
              : `Withdrawal request for ₽${finalAmount} to ${phoneNumber} created\nWill arrive in 1-3 business days`
          );
        } else {
          const card = cards.find(c => c.id === selectedCard);
          alert(
            language === 'ru'
              ? `Заявка на вывод ₽${finalAmount} на карту ${card?.brand} •••• ${card?.last4} создана\nПоступит за 1-3 рабочих дня`
              : `Withdrawal request for ₽${finalAmount} to ${card?.brand} •••• ${card?.last4} created\nWill arrive in 1-3 business days`
          );
        }
        setAmount("");
      } else {
        alert(language === 'ru' ? "Ошибка при создании заявки" : "Error creating withdrawal");
      }
    } catch (error) {
      alert(language === 'ru' ? "Ошибка подключения" : "Connection error");
    } finally {
      setLoading(false);
    }
  };

  const handleAddCard = () => {
    if (!newCard.cardNumber || !newCard.cardHolder || !newCard.expiryDate || !newCard.cvv) {
      alert(language === 'ru' ? "Заполните все поля" : "Fill all fields");
      return;
    }
    const newCardObj: SavedCard = {
      id: `card_${Date.now()}`,
      last4: newCard.cardNumber.slice(-4),
      brand: "Card",
      expiryDate: newCard.expiryDate,
    };
    setCards([...cards, newCardObj]);
    alert(language === 'ru' 
      ? `Карта ${newCard.cardNumber.slice(-4)} успешно добавлена!`
      : `Card ${newCard.cardNumber.slice(-4)} added successfully!`);
    setNewCard({ cardNumber: "", cardHolder: "", expiryDate: "", cvv: "" });
    setShowNewCardForm(false);
  };

  const handleDeleteCard = (cardId: string) => {
    if (selectedCard === cardId) {
      setSelectedCard(null);
    }
    setCards(cards.filter(card => card.id !== cardId));
    alert(language === 'ru' ? "Карта удалена!" : "Card deleted!");
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl font-black font-orbitron text-white mb-2">
                {language === 'ru' ? 'Вывод средств' : 'Withdraw Funds'}
              </h1>
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Выведите свои заработки' : 'Withdraw your earnings'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-muted-foreground text-sm mb-1">{language === 'ru' ? 'Доступно:' : 'Available:'}</p>
              <p className="text-4xl font-bold text-green-400 font-mono">
                ₽{user.balance.toLocaleString('ru-RU')}
              </p>
            </div>
          </div>
        </div>
        <Tabs defaultValue="withdraw" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-black/20">
            <TabsTrigger value="withdraw">{language === 'ru' ? 'Вывести' : 'Withdraw'}</TabsTrigger>
            <TabsTrigger value="cards">{language === 'ru' ? 'Мои карты' : 'My Cards'}</TabsTrigger>
          </TabsList>

          <TabsContent value="withdraw">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Withdrawal Form */}
              <div className="lg:col-span-2 glass-panel p-6 rounded-2xl space-y-6">
                {/* Payment Method Selection */}
                <div>
                  <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                    {language === 'ru' ? 'Способ получения' : 'Withdrawal Method'}
                  </h3>
                  <div className="space-y-3">
                    <div
                      onClick={() => { setPaymentMethod("tinkoff"); setSelectedCard(null); }}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        paymentMethod === "tinkoff"
                          ? "bg-blue-600/20 border-blue-500"
                          : "bg-white/5 border-white/10 hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Wallet className="w-5 h-5 text-blue-400" />
                          <div>
                            <p className="font-bold text-white">Tinkoff</p>
                            <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Переводом' : 'Transfer'}</p>
                          </div>
                        </div>
                        {paymentMethod === "tinkoff" && (
                          <Check className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </div>

                    <div
                      onClick={() => setPaymentMethod("card")}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        paymentMethod === "card"
                          ? "bg-purple-600/20 border-purple-500"
                          : "bg-white/5 border-white/10 hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CreditCard className="w-5 h-5 text-purple-400" />
                          <div>
                            <p className="font-bold text-white">{language === 'ru' ? 'На карту' : 'To Card'}</p>
                            <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Банковская карта' : 'Bank card'}</p>
                          </div>
                        </div>
                        {paymentMethod === "card" && (
                          <Check className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </div>

                    <div
                      onClick={() => setPaymentMethod("phone")}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        paymentMethod === "phone"
                          ? "bg-green-600/20 border-green-500"
                          : "bg-white/5 border-white/10 hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Smartphone className="w-5 h-5 text-green-400" />
                          <div>
                            <p className="font-bold text-white">{language === 'ru' ? 'На номер' : 'To Phone'}</p>
                            <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Привязанный номер' : 'Linked number'}</p>
                          </div>
                        </div>
                        {paymentMethod === "phone" && (
                          <Check className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Phone Number Input - Only show when phone is selected */}
                {paymentMethod === "phone" && (
                  <div>
                    <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                      {language === 'ru' ? 'Номер телефона' : 'Phone Number'}
                    </h3>
                    <div className="space-y-4">
                      {/* Bank Selection */}
                      <div>
                        <Label className="text-sm">{language === 'ru' ? 'Выберите банк' : 'Select Bank'}</Label>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          {BANKS.map((bank) => (
                            <button
                              key={bank.id}
                              onClick={() => setSelectedBank(bank.id)}
                              className={`p-3 rounded-lg border-2 transition-all text-sm font-bold cursor-pointer ${
                                selectedBank === bank.id
                                  ? "bg-blue-600/30 border-blue-500"
                                  : "bg-white/5 border-white/10 hover:border-white/20"
                              }`}
                            >
                              {language === 'ru' ? bank.ru : bank.name}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Phone Number Input */}
                      <div className="relative">
                        <Label htmlFor="phone">{language === 'ru' ? 'Номер (+7)' : 'Number (+7)'}</Label>
                        <div className="relative mt-2">
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+79991234567"
                            value={phoneNumber}
                            onChange={(e) => {
                              let val = e.target.value.replace(/\D/g, '');
                              if (!val.startsWith('7')) val = '7' + val;
                              setPhoneNumber('+' + val.slice(0, 11));
                            }}
                            className="bg-black/30 border-white/10 h-12 text-lg font-mono"
                          />
                        </div>
                      </div>

                      {/* Bank Info Card */}
                      <div className="bg-gradient-to-r from-blue-600/20 to-blue-500/10 border border-blue-500/30 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Привязанный банк' : 'Linked Bank'}</p>
                        <p className="text-lg font-bold text-blue-300">
                          {language === 'ru' 
                            ? BANKS.find(b => b.id === selectedBank)?.ru 
                            : BANKS.find(b => b.id === selectedBank)?.name}
                        </p>
                      </div>

                      <div className="bg-green-600/10 border border-green-500/30 p-3 rounded-lg text-sm text-green-200">
                        {language === 'ru' ? '✓ Номер действителен' : '✓ Number is valid'}
                      </div>
                    </div>
                  </div>
                )}

                {/* Card Selection - Only show when card is selected */}
                {paymentMethod === "card" && (
                  <div>
                    <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                      {language === 'ru' ? 'Выберите карту' : 'Select Card'}
                    </h3>
                    <div className="space-y-3">
                      {cards.length > 0 ? (
                        cards.map((card) => (
                          <div
                            key={card.id}
                            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              selectedCard === card.id
                                ? "bg-primary/20 border-primary"
                                : "bg-white/5 border-white/10 hover:border-white/20"
                            }`}
                            onClick={() => setSelectedCard(card.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <CreditCard className="w-5 h-5 text-secondary" />
                                <div>
                                  <p className="font-bold text-white">
                                    {card.brand} •••• {card.last4}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {language === 'ru' ? 'Действительна до' : 'Valid until'} {card.expiryDate}
                                  </p>
                                </div>
                              </div>
                              {selectedCard === card.id && (
                                <Check className="w-5 h-5 text-green-400" />
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-muted-foreground text-center py-4">
                          {language === 'ru' ? 'Нет сохраненных карт' : 'No saved cards'}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Amount Selection */}
                <div>
                  <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                    {language === 'ru' ? 'Сумма вывода' : 'Withdrawal Amount'}
                  </h3>
                  <div className="space-y-4">
                    <div className="relative">
                      <Label htmlFor="amount">{language === 'ru' ? 'Сумма (₽)' : 'Amount (₽)'}</Label>
                      <div className="relative mt-2">
                        <span className="absolute left-3 top-3.5 text-primary font-bold text-lg">₽</span>
                        <Input
                          id="amount"
                          type="number"
                          placeholder="100"
                          min="100"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="pl-10 bg-black/30 border-white/10 h-12 text-lg"
                        />
                      </div>
                    </div>

                    {/* Quick Amount Buttons */}
                    <div className="grid grid-cols-5 gap-2">
                      {[100, 250, 500, 1000].map((amt) => (
                        <Button
                          key={amt}
                          variant="outline"
                          onClick={() => setAmount(amt.toString())}
                          className="bg-white/5 border-white/10 hover:bg-white/10 text-sm"
                        >
                          ₽{amt}
                        </Button>
                      ))}
                      <Button
                        variant="outline"
                        onClick={() => setAmount(user.balance.toString())}
                        className="bg-green-600/20 border-green-500/50 hover:bg-green-600/30 text-green-300 font-bold text-sm"
                      >
                        MAX
                      </Button>
                    </div>

                    {amount && (
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="flex justify-between mb-2">
                          <span className="text-muted-foreground">{language === 'ru' ? 'К выводу:' : 'To withdraw:'}</span>
                          <span className="text-white font-bold">₽{parseFloat(amount).toLocaleString('ru-RU')}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span className="text-muted-foreground">{language === 'ru' ? 'Комиссия (1%):' : 'Commission (1%):'}</span>
                          <span className="text-white font-bold">
                            ₽{(parseFloat(amount) * 0.01).toLocaleString('ru-RU')}
                          </span>
                        </div>
                        <div className="border-t border-white/10 pt-2 flex justify-between">
                          <span className="text-muted-foreground">{language === 'ru' ? 'Вы получите:' : 'You will receive:'}</span>
                          <span className="text-green-400 font-bold text-lg">
                            ₽{(parseFloat(amount) * 0.99).toLocaleString('ru-RU')}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Info & Warning */}
                <div className="bg-yellow-500/10 border border-yellow-500/30 p-4 rounded-lg flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-200">
                    <p className="font-bold mb-1">{language === 'ru' ? 'Важно:' : 'Important:'}</p>
                    <p>
                      {language === 'ru'
                        ? 'Вывод обрабатывается 1-3 рабочих дня. Комиссия 1%. Минимум ₽100.'
                        : 'Withdrawal processing 1-3 business days. Commission 1%. Minimum ₽100.'}
                    </p>
                  </div>
                </div>

                {/* Withdraw Button */}
                <Button
                  onClick={handleWithdraw}
                  disabled={!amount || loading || (paymentMethod === "card" && !selectedCard)}
                  className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg font-bold"
                >
                  {loading
                    ? (language === 'ru' ? 'Обработка...' : 'Processing...')
                    : (language === 'ru' ? `Вывести ₽${amount ? (parseFloat(amount) * 0.99).toLocaleString('ru-RU') : '0'}` : `Withdraw ₽${amount ? (parseFloat(amount) * 0.99).toLocaleString('ru-RU') : '0'}`)}
                </Button>
              </div>

              {/* Info Sidebar */}
              <div className="space-y-4">
                <Card className="glass-panel p-6 rounded-2xl border-white/10">
                  <h4 className="font-bold text-white mb-3 font-orbitron">
                    {language === 'ru' ? 'О выводе' : 'About Withdrawal'}
                  </h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>✓ {language === 'ru' ? 'Быстрый перевод' : 'Fast transfer'}</p>
                    <p>✓ {language === 'ru' ? 'Только 1% комиссия' : 'Only 1% commission'}</p>
                    <p>✓ {language === 'ru' ? 'Безопасно' : 'Secure'}</p>
                  </div>
                </Card>

                {paymentMethod === "tinkoff" && (
                  <Card className="glass-panel p-6 rounded-2xl border-white/10 bg-purple-600/10 border-purple-500/30">
                    <h4 className="font-bold text-white mb-3 font-orbitron">
                      {language === 'ru' ? 'Номер Tinkoff' : 'Tinkoff Number'}
                    </h4>
                    <p className="text-2xl font-bold text-primary font-mono mb-2">{TINKOFF_PHONE}</p>
                    <p className="text-xs text-muted-foreground">
                      {language === 'ru' ? 'Переводы поступают сюда' : 'Transfers arrive here'}
                    </p>
                  </Card>
                )}

                <Card className="glass-panel p-6 rounded-2xl border-white/10">
                  <h4 className="font-bold text-white mb-3 font-orbitron">
                    {language === 'ru' ? 'Лимиты' : 'Limits'}
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div>
                      <p className="text-muted-foreground mb-1">{language === 'ru' ? 'Минимум:' : 'Minimum:'}</p>
                      <p className="text-white font-bold">₽100</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-1">{language === 'ru' ? 'Максимум:' : 'Maximum:'}</p>
                      <p className="text-white font-bold">₽500 000</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-1">{language === 'ru' ? 'Комиссия:' : 'Commission:'}</p>
                      <p className="text-white font-bold">1%</p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Cards Tab */}
          <TabsContent value="cards">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Saved Cards */}
              <div className="lg:col-span-2 space-y-4">
                {cards.length > 0 ? (
                  cards.map((card) => (
                    <div
                      key={card.id}
                      className="glass-panel p-6 rounded-2xl flex items-center justify-between"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-secondary to-orange-700 flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="font-bold text-white text-lg">
                            {card.brand} •••• {card.last4}
                          </p>
                          <p className="text-muted-foreground text-sm">
                            {language === 'ru' ? 'Действительна до' : 'Valid until'} {card.expiryDate}
                          </p>
                        </div>
                      </div>
                      <Button 
                        variant="destructive"
                        onClick={() => handleDeleteCard(card.id)}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        {language === 'ru' ? 'Удалить' : 'Delete'}
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="glass-panel p-8 rounded-2xl text-center">
                    <p className="text-muted-foreground">{language === 'ru' ? 'Нет сохраненных карт' : 'No saved cards'}</p>
                  </div>
                )}
              </div>

              {/* Add New Card */}
              <div className="glass-panel p-6 rounded-2xl h-fit">
                <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                  {language === 'ru' ? 'Добавить карту' : 'Add Card'}
                </h3>
                <Button
                  onClick={() => setShowNewCardForm(!showNewCardForm)}
                  className="w-full bg-primary hover:bg-primary/90 mb-4"
                >
                  + {language === 'ru' ? 'Новая карта' : 'New Card'}
                </Button>

                {showNewCardForm && (
                  <div className="space-y-3 border-t border-white/10 pt-4">
                    <div>
                      <Label htmlFor="cardNumber" className="text-xs">
                        {language === 'ru' ? 'Номер карты' : 'Card Number'}
                      </Label>
                      <Input
                        id="cardNumber"
                        placeholder="4242 4242 4242 4242"
                        value={newCard.cardNumber}
                        onChange={(e) =>
                          setNewCard({ ...newCard, cardNumber: e.target.value })
                        }
                        className="bg-black/30 border-white/10 text-sm mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="cardHolder" className="text-xs">
                        {language === 'ru' ? 'ФИО владельца' : 'Cardholder Name'}
                      </Label>
                      <Input
                        id="cardHolder"
                        placeholder="Ivan Petrov"
                        value={newCard.cardHolder}
                        onChange={(e) =>
                          setNewCard({ ...newCard, cardHolder: e.target.value })
                        }
                        className="bg-black/30 border-white/10 text-sm mt-1"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor="expiryDate" className="text-xs">
                          {language === 'ru' ? 'Дата' : 'Expiry'}
                        </Label>
                        <Input
                          id="expiryDate"
                          placeholder="MM/YY"
                          value={newCard.expiryDate}
                          onChange={(e) =>
                            setNewCard({ ...newCard, expiryDate: e.target.value })
                          }
                          className="bg-black/30 border-white/10 text-sm mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv" className="text-xs">
                          CVV
                        </Label>
                        <Input
                          id="cvv"
                          placeholder="123"
                          value={newCard.cvv}
                          onChange={(e) =>
                            setNewCard({ ...newCard, cvv: e.target.value })
                          }
                          className="bg-black/30 border-white/10 text-sm mt-1"
                        />
                      </div>
                    </div>
                    <Button
                      onClick={handleAddCard}
                      className="w-full bg-secondary hover:bg-secondary/90 text-black font-bold mt-4"
                    >
                      {language === 'ru' ? 'Добавить карту' : 'Add Card'}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
