import Layout from "@/components/layout";
import { useLanguage } from "@/lib/language-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, Users, TrendingUp, Zap, Lock, Trash2, Unlock, Eye, X } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";

interface Transaction {
  id: string;
  type: "bet" | "win" | "deposit" | "withdraw";
  amount: number;
  date: string;
  description: string;
}

interface User {
  id: string;
  username: string;
  email: string;
  balance: number;
  status: "active" | "blocked";
  joinDate: string;
  totalBets?: number;
  totalWins?: number;
  winRate?: number;
  lastActivity?: string;
  transactions?: Transaction[];
}

export default function AdminPage() {
  const { language } = useLanguage();
  const [, setLocation] = useLocation();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [fundAmount, setFundAmount] = useState("");
  
  const [users, setUsers] = useState<User[]>([
    { 
      id: "1", 
      username: "player_123", 
      email: "player1@example.com", 
      balance: 5420, 
      status: "active", 
      joinDate: "2025-01-15",
      totalBets: 15,
      totalWins: 8,
      winRate: 53.3,
      lastActivity: "2025-01-30 18:45",
      transactions: [
        { id: "t1", type: "bet", amount: -500, date: "2025-01-30 18:45", description: "Ставка в Ракету" },
        { id: "t2", type: "win", amount: 1200, date: "2025-01-30 18:42", description: "Выигрыш в Ракету x2.4" },
        { id: "t3", type: "bet", amount: -300, date: "2025-01-30 18:30", description: "Ставка в Бомбер" },
      ]
    },
    { 
      id: "2", 
      username: "rocket_master", 
      email: "player2@example.com", 
      balance: 12340, 
      status: "active", 
      joinDate: "2025-01-10",
      totalBets: 42,
      totalWins: 28,
      winRate: 66.7,
      lastActivity: "2025-01-30 19:20",
      transactions: [
        { id: "t4", type: "deposit", amount: 5000, date: "2025-01-29 14:30", description: "Пополнение через Tinkoff" },
        { id: "t5", type: "win", amount: 2340, date: "2025-01-30 19:15", description: "Выигрыш в Ракету x3.1" },
      ]
    },
    { 
      id: "3", 
      username: "bomber_pro", 
      email: "player3@example.com", 
      balance: 3210, 
      status: "active", 
      joinDate: "2025-01-20",
      totalBets: 28,
      totalWins: 15,
      winRate: 53.6,
      lastActivity: "2025-01-30 17:50",
      transactions: [
        { id: "t6", type: "withdraw", amount: -2000, date: "2025-01-28 16:20", description: "Вывод на Sberbank" },
      ]
    },
    { 
      id: "4", 
      username: "test_user", 
      email: "test@example.com", 
      balance: 1500, 
      status: "blocked", 
      joinDate: "2025-01-05",
      totalBets: 5,
      totalWins: 1,
      winRate: 20.0,
      lastActivity: "2025-01-25 12:30",
      transactions: []
    },
    { 
      id: "5", 
      username: "high_roller", 
      email: "roller@example.com", 
      balance: 45600, 
      status: "active", 
      joinDate: "2024-12-28",
      totalBets: 120,
      totalWins: 89,
      winRate: 74.2,
      lastActivity: "2025-01-30 19:55",
      transactions: [
        { id: "t7", type: "deposit", amount: 10000, date: "2025-01-20 10:15", description: "Пополнение через Tinkoff" },
        { id: "t8", type: "win", amount: 8900, date: "2025-01-30 19:50", description: "Большой выигрыш в Ракету x5.6" },
      ]
    },
  ]);

  useEffect(() => {
    const accessGranted = localStorage.getItem("admin_access");
    if (!accessGranted) {
      setLocation("/");
    }
  }, [setLocation]);

  const handleBlockUser = (userId: string) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === "active" ? "blocked" : "active" }
        : user
    ));
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm(language === 'ru' ? 'Вы уверены? Это действие необратимо!' : 'Are you sure? This action cannot be undone!')) {
      setUsers(users.filter(user => user.id !== userId));
    }
  };

  const handleAddFunds = (userId: string, amount: number) => {
    if (amount <= 0) {
      alert(language === 'ru' ? 'Введите корректную сумму' : 'Enter a valid amount');
      return;
    }
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, balance: user.balance + amount }
        : user
    ));
    setSelectedUser(selectedUser ? { ...selectedUser, balance: selectedUser.balance + amount } : null);
    setFundAmount("");
  };

  const handleRemoveFunds = (userId: string, amount: number) => {
    if (amount <= 0) {
      alert(language === 'ru' ? 'Введите корректную сумму' : 'Enter a valid amount');
      return;
    }
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, balance: Math.max(0, user.balance - amount) }
        : user
    ));
    setSelectedUser(selectedUser ? { ...selectedUser, balance: Math.max(0, selectedUser.balance - amount) } : null);
    setFundAmount("");
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-black font-orbitron text-white mb-2">
                {language === 'ru' ? 'Панель администратора' : 'Admin Panel'}
              </h1>
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Управление платформой SHOTO' : 'Manage SHOTO platform'}
              </p>
            </div>
            <Zap className="w-12 h-12 text-green-400" />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Активных игроков' : 'Active Players'}
                </p>
                <p className="text-3xl font-bold text-green-400">{users.filter(u => u.status === 'active').length}</p>
              </div>
              <Users className="w-10 h-10 text-green-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Общий оборот' : 'Total Turnover'}
                </p>
                <p className="text-3xl font-bold text-blue-400">₽{users.reduce((sum, u) => sum + u.balance, 0).toLocaleString('ru-RU')}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-blue-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Заблокировано' : 'Blocked'}
                </p>
                <p className="text-3xl font-bold text-orange-400">{users.filter(u => u.status === 'blocked').length}</p>
              </div>
              <BarChart3 className="w-10 h-10 text-orange-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Всего игроков' : 'Total Players'}
                </p>
                <p className="text-3xl font-bold text-purple-400">{users.length}</p>
              </div>
              <Zap className="w-10 h-10 text-purple-400/30" />
            </div>
          </Card>
        </div>

        {/* Users Management */}
        <div className="glass-panel p-6 rounded-2xl space-y-6">
          <h2 className="text-2xl font-bold font-orbitron text-white">
            {language === 'ru' ? 'Управление игроками' : 'Player Management'}
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Ник' : 'Username'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Email' : 'Email'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Баланс' : 'Balance'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Статус' : 'Status'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Дата входа' : 'Joined'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Действия' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="px-4 py-4 text-white font-mono font-bold">{user.username}</td>
                    <td className="px-4 py-4 text-muted-foreground text-xs">{user.email}</td>
                    <td className="px-4 py-4 text-green-400 font-bold">₽{user.balance.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        user.status === 'active'
                          ? 'bg-green-600/20 text-green-400'
                          : 'bg-red-600/20 text-red-400'
                      }`}>
                        {user.status === 'active' 
                          ? (language === 'ru' ? 'Активен' : 'Active')
                          : (language === 'ru' ? 'Заблокирован' : 'Blocked')}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-muted-foreground text-xs">{user.joinDate}</td>
                    <td className="px-4 py-4">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          onClick={() => setSelectedUser(user)}
                          className="bg-blue-600 hover:bg-blue-700 text-xs h-8"
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          {language === 'ru' ? 'Просмотр' : 'View'}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleBlockUser(user.id)}
                          className={user.status === 'active' 
                            ? 'bg-orange-600 hover:bg-orange-700 text-xs h-8'
                            : 'bg-green-600 hover:bg-green-700 text-xs h-8'}
                        >
                          {user.status === 'active' ? (
                            <>
                              <Lock className="w-3 h-3 mr-1" />
                              {language === 'ru' ? 'Блок' : 'Block'}
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3 h-3 mr-1" />
                              {language === 'ru' ? 'Разб' : 'Unblock'}
                            </>
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteUser(user.id)}
                          className="bg-red-600 hover:bg-red-700 text-xs h-8"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {users.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Нет игроков' : 'No players'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="glass-panel rounded-2xl max-w-2xl w-full max-h-96 overflow-y-auto p-6 border border-white/10 space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold font-orbitron text-white">{selectedUser.username}</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedUser(null)}
                className="text-muted-foreground hover:text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* User Info Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Email' : 'Email'}</p>
                <p className="text-sm font-mono text-white">{selectedUser.email}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Баланс' : 'Balance'}</p>
                <p className="text-sm font-bold text-green-400">₽{selectedUser.balance.toLocaleString('ru-RU')}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Дата входа' : 'Join Date'}</p>
                <p className="text-sm text-white">{selectedUser.joinDate}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Последняя активность' : 'Last Activity'}</p>
                <p className="text-sm text-white">{selectedUser.lastActivity}</p>
              </div>
            </div>

            {/* Statistics */}
            <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
              <h3 className="font-bold text-white">{language === 'ru' ? 'Статистика' : 'Statistics'}</h3>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Ставок' : 'Bets'}</p>
                  <p className="text-lg font-bold text-blue-400">{selectedUser.totalBets}</p>
                </div>
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Выигрышей' : 'Wins'}</p>
                  <p className="text-lg font-bold text-green-400">{selectedUser.totalWins}</p>
                </div>
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Win Rate' : 'Win Rate'}</p>
                  <p className="text-lg font-bold text-yellow-400">{selectedUser.winRate}%</p>
                </div>
              </div>
            </div>

            {/* Recent Transactions */}
            {selectedUser.transactions && selectedUser.transactions.length > 0 && (
              <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
                <h3 className="font-bold text-white">{language === 'ru' ? 'Последние транзакции' : 'Recent Transactions'}</h3>
                <div className="space-y-2">
                  {selectedUser.transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between text-xs bg-black/20 p-2 rounded">
                      <div>
                        <p className="text-white font-mono">{tx.description}</p>
                        <p className="text-muted-foreground text-xs">{tx.date}</p>
                      </div>
                      <p className={tx.amount > 0 ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>
                        {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString('ru-RU')}₽
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Funds Management */}
            <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
              <h3 className="font-bold text-white">{language === 'ru' ? 'Управление средствами' : 'Fund Management'}</h3>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={fundAmount}
                  onChange={(e) => setFundAmount(e.target.value)}
                  placeholder={language === 'ru' ? 'Сумма (₽)' : 'Amount (₽)'}
                  className="flex-1 bg-black/30 border border-white/10 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-green-500"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => handleAddFunds(selectedUser.id, parseFloat(fundAmount))}
                  disabled={!fundAmount}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-sm h-8"
                >
                  {language === 'ru' ? '+ Выдать' : '+ Add'}
                </Button>
                <Button
                  onClick={() => handleRemoveFunds(selectedUser.id, parseFloat(fundAmount))}
                  disabled={!fundAmount}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-sm h-8"
                >
                  {language === 'ru' ? '- Отобрать' : '- Remove'}
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4">
              <Button
                onClick={() => {
                  handleBlockUser(selectedUser.id);
                  setSelectedUser(null);
                }}
                className={selectedUser.status === 'active' 
                  ? 'bg-orange-600 hover:bg-orange-700 flex-1'
                  : 'bg-green-600 hover:bg-green-700 flex-1'}
              >
                {selectedUser.status === 'active' 
                  ? (language === 'ru' ? 'Блокировать' : 'Block')
                  : (language === 'ru' ? 'Разблокировать' : 'Unblock')}
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  handleDeleteUser(selectedUser.id);
                  setSelectedUser(null);
                }}
                className="flex-1 bg-red-600 hover:bg-red-700"
              >
                {language === 'ru' ? 'Удалить' : 'Delete'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
