import Layout from "@/components/layout";
import { INITIAL_USER, MOCK_TRANSACTIONS, TRANSACTION_TYPE_LABELS, TRANSACTION_STATUS_LABELS } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Wallet, TrendingUp, Calendar, CreditCard, Mail, User as UserIcon, Copy, Share2, Users, Zap, Ticket } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export default function ProfilePage() {
  const [, setLocation] = useLocation();
  const [userId, setUserId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [isApplyingCode, setIsApplyingCode] = useState(false);
  const [isPromoModalOpen, setIsPromoModalOpen] = useState(false);
  const user = INITIAL_USER;
  const completedTransactions: any[] = [];
  const totalDeposits = 0;

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      setUserId(JSON.parse(user).id);
    }
  }, []);

  const { data: referral } = useQuery({
    queryKey: [`/api/referrals/${userId}`],
    queryFn: async () => {
      const res = await fetch(`/api/referrals/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch referral");
      return res.json();
    },
    enabled: !!userId,
  });

  const { data: invitedUsers = [] } = useQuery({
    queryKey: [`/api/referrals/${userId}/invited`],
    queryFn: async () => {
      if (!referral) return [];
      const res = await fetch(`/api/referrals/${userId}/invited`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!referral,
  });

  const { data: referrerInfo } = useQuery({
    queryKey: [`/api/referrals/${userId}/referrer`],
    queryFn: async () => {
      const res = await fetch(`/api/referrals/${userId}/referrer`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!userId,
  });

  const handleCreateReferral = async () => {
    if (!userId) return;
    try {
      const res = await fetch("/api/referrals/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ referrerId: userId }),
      });
      if (!res.ok) throw new Error();
      toast.success("Реферальный код создан!");
      
      // Wait a moment for data to update, then refresh
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch {
      toast.error("Ошибка при создании кода");
    }
  };

  const handleInviteShare = async () => {
    if (referral?.referralLink) {
      window.open(referral.referralLink, '_blank');
    } else {
      // No referral yet, create one first
      await handleCreateReferral();
    }
  };

  const handleApplyPromoCode = async () => {
    if (!promoCode.trim() || !userId) {
      toast.error("Введите промокод");
      return;
    }
    
    setIsApplyingCode(true);
    try {
      const res = await fetch("/api/referrals/apply-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ promoCode: promoCode.toUpperCase(), userId }),
      });
      
      if (!res.ok) {
        const error = await res.json();
        toast.error(error.error || "Неверный промокод");
        return;
      }
      
      toast.success("Промокод применён! Бонус добавлен!");
      setPromoCode("");
      window.location.reload();
    } catch (error) {
      toast.error("Ошибка при применении промокода");
    } finally {
      setIsApplyingCode(false);
    }
  };

  const handleCopyCode = () => {
    if (referral?.promoCode) {
      navigator.clipboard.writeText(referral.promoCode);
      setCopied(true);
      toast.success("Код скопирован!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyLink = () => {
    if (referral?.referralLink) {
      navigator.clipboard.writeText(referral.referralLink);
      setCopied(true);
      toast.success("Ссылка скопирована!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    if (referral?.referralLink) {
      if (navigator.share) {
        try {
          await navigator.share({
            title: "SHOTO Referral",
            text: `Присоединись ко мне на SHOTO! Используй мой код: ${referral.promoCode}`,
            url: referral.referralLink,
          });
        } catch {
          handleCopyLink();
        }
      } else {
        handleCopyLink();
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'rejected':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return '↓';
      case 'withdrawal':
        return '↑';
      case 'earning':
        return '🚀';
      default:
        return '→';
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Profile Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-4xl font-black font-orbitron text-white mb-4">
                {user.username}
              </h1>
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <UserIcon className="w-4 h-4 text-blue-400" />
                  <span className="text-sm">Логин: <span className="text-white font-mono font-bold">{user.username}</span></span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="w-4 h-4 text-green-400" />
                  <span className="text-sm">Email: <span className="text-white font-mono font-bold">{user.email}</span></span>
                </div>
              </div>
              <p className="text-muted-foreground text-xs">Участник с {user.createdAt}</p>
              {referrerInfo && (
                <p className="text-muted-foreground text-xs mt-2 text-cyan-400">
                  💫 Приглашён: <span className="text-white font-semibold">{referrerInfo.username}</span> (код: {referrerInfo.promoCode})
                </p>
              )}
            </div>
            <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center">
              <Wallet className="w-8 h-8 text-white" />
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div 
              onClick={() => setLocation("/withdrawal")}
              className="bg-black/20 p-4 rounded-lg border border-white/5 hover:border-green-500/50 hover:bg-black/40 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-2 mb-2">
                <Wallet className="w-4 h-4 text-primary group-hover:text-green-400 transition-colors" />
                <p className="text-muted-foreground text-sm group-hover:text-green-400 transition-colors">Текущий баланс</p>
              </div>
              <p className="text-3xl font-bold text-green-400 font-mono group-hover:text-green-300 transition-colors">₽{user.balance.toLocaleString('ru-RU')}</p>
            </div>

            <div className="bg-black/20 p-4 rounded-lg border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-secondary" />
                <p className="text-muted-foreground text-sm">Всего заработано</p>
              </div>
              <p className="text-3xl font-bold text-yellow-400 font-mono">₽{user.totalEarned.toLocaleString('ru-RU')}</p>
            </div>

            <div className="bg-black/20 p-4 rounded-lg border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="w-4 h-4 text-blue-400" />
                <p className="text-muted-foreground text-sm">Всего пополнено</p>
              </div>
              <p className="text-3xl font-bold text-blue-400 font-mono">₽{totalDeposits.toLocaleString('ru-RU')}</p>
            </div>
          </div>
        </div>

        {/* Referral Section */}
        {referral ? (
          <div className="glass-panel p-6 rounded-2xl border border-purple-500/30 bg-purple-500/10">
            <h2 className="text-xl font-bold font-orbitron mb-4 text-white flex items-center gap-2">
              <Share2 className="w-5 h-5" />
              Твой реферальный код
            </h2>
            <div className="space-y-4">
              <div className="p-4 bg-black/50 rounded-lg border border-purple-500/50 flex items-center justify-between" data-testid="display-promo-code">
                <code className="text-lg font-bold text-purple-400">{referral.promoCode}</code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleCopyCode}
                  data-testid="button-copy-code"
                  className="hover:bg-purple-500/20"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="p-3 bg-black/50 rounded-lg border border-cyan-500/50 flex items-center justify-between text-sm" data-testid="display-referral-link">
                <a 
                  href={referral.referralLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-cyan-400 truncate flex-1 hover:text-cyan-300 hover:underline cursor-pointer text-xs font-mono"
                  data-testid="link-referral"
                >
                  {referral.referralLink}
                </a>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleCopyLink}
                  data-testid="button-copy-link"
                  className="hover:bg-cyan-500/20 ml-2"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-black/50 p-3 rounded-lg border border-blue-500/30">
                  <p className="text-xs text-muted-foreground mb-1">Приглашено</p>
                  <p className="text-2xl font-bold text-blue-400" data-testid="text-referral-count">{referral.referralCount}</p>
                </div>
                <div className="bg-black/50 p-3 rounded-lg border border-yellow-500/30">
                  <p className="text-xs text-muted-foreground mb-1">Заработано</p>
                  <p className="text-2xl font-bold text-yellow-400" data-testid="text-total-commission">₽{parseFloat(referral.totalCommission).toFixed(0)}</p>
                </div>
              </div>

              <Button
                onClick={handleInviteShare}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                data-testid="button-share-referral"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Поделиться со ссылкой
              </Button>

              {invitedUsers.length > 0 && (
                <div className="mt-6 space-y-3">
                  <h3 className="text-sm font-bold text-purple-400 uppercase">Приглашённые друзья ({invitedUsers.length})</h3>
                  {invitedUsers.map((invitedUser: any, index: number) => (
                    <div 
                      key={invitedUser.id}
                      className="p-4 bg-black/50 rounded-lg border border-blue-500/30 flex items-center justify-between"
                      data-testid={`row-invited-${index}`}
                    >
                      <div className="flex-1">
                        <p className="font-bold text-white" data-testid={`text-username-${index}`}>{invitedUser.username}</p>
                        <p className="text-xs text-muted-foreground">Присоединился: {new Date(invitedUser.referredAt).toLocaleDateString('ru-RU')}</p>
                      </div>
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
                        data-testid={`button-claim-bonus-${index}`}
                        onClick={() => toast.success("Бонус учтён!")}
                      >
                        💰 Бонус
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="glass-panel p-6 rounded-2xl border border-purple-500/30 bg-purple-500/10 space-y-4">
            <h2 className="text-xl font-bold font-orbitron mb-4 text-white flex items-center gap-2">
              <Share2 className="w-5 h-5" />
              Реферальная программа
            </h2>
            <p className="text-muted-foreground">Начни зарабатывать 10% комиссии на депозиты рефералов</p>
            <Button
              onClick={handleInviteShare}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 w-full"
              data-testid="button-create-referral"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Пригласить друга
            </Button>
            
            <div className="border-t border-purple-500/30 pt-4">
              <p className="text-sm text-muted-foreground mb-3">Есть промокод? Введи его здесь:</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Введи промокод"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleApplyPromoCode()}
                  className="flex-1 px-3 py-2 bg-black/50 border border-blue-500/30 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                  data-testid="input-promo-code"
                />
                <Button
                  onClick={handleApplyPromoCode}
                  disabled={isApplyingCode}
                  className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
                  data-testid="button-apply-promo"
                >
                  Применить
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="glass-panel p-6 rounded-2xl">
          <h2 className="text-xl font-bold font-orbitron mb-4 text-white">Быстрые действия</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Button className="bg-green-600 hover:bg-green-700" onClick={() => setLocation("/deposit")}>+ Пополнить</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setLocation("/withdrawal")}>↓ Вывести</Button>
            <Button 
              onClick={() => setIsPromoModalOpen(true)}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
              data-testid="button-open-promo-modal"
            >
              <Ticket className="w-4 h-4 mr-2" />
              Промокод
            </Button>
            <Button onClick={() => setLocation("/settings")} variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10">Настройки</Button>
          </div>
        </div>

        {/* Promo Code Modal */}
        <Dialog open={isPromoModalOpen} onOpenChange={setIsPromoModalOpen}>
          <DialogContent className="border border-cyan-500/30 bg-black/80">
            <DialogHeader>
              <DialogTitle className="text-2xl font-orbitron text-white flex items-center gap-2">
                <Ticket className="w-6 h-6 text-cyan-400" />
                Ввести промокод
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                Введи промокод и получи бонус ₽10
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 mt-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">Промокод:</label>
                <input
                  type="text"
                  placeholder="Например: A1B2C3"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                  onKeyPress={(e) => e.key === "Enter" && handleApplyPromoCode()}
                  className="w-full px-4 py-3 bg-black/50 border border-blue-500/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 text-center text-lg font-mono tracking-widest"
                  data-testid="input-promo-code-modal"
                />
              </div>
              
              <div className="flex gap-3">
                <Button
                  onClick={handleApplyPromoCode}
                  disabled={isApplyingCode}
                  className="flex-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-bold py-3"
                  data-testid="button-apply-promo-modal"
                >
                  {isApplyingCode ? "Применяю..." : "Применить"}
                </Button>
                <Button
                  onClick={() => setIsPromoModalOpen(false)}
                  variant="outline"
                  className="flex-1 bg-white/5 border-white/10 hover:bg-white/10"
                >
                  Отмена
                </Button>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 text-sm text-blue-200">
                <p className="font-semibold mb-2">💡 Как получить промокод?</p>
                <ul className="space-y-1 text-xs">
                  <li>• Каждый промокод даёт ₽10 бонуса</li>
                  <li>• Один код можно использовать один раз</li>
                  <li>• Попроси код у друга, который играет на SHOTO</li>
                </ul>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Recent Transactions */}
        <div className="glass-panel p-6 rounded-2xl">
          <h2 className="text-xl font-bold font-orbitron mb-4 text-white flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            История транзакций
          </h2>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {completedTransactions.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Нет транзакций</p>
            ) : (
              completedTransactions.map((txn) => (
                <div
                  key={txn.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/5"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="text-2xl">{getTypeIcon(txn.type)}</div>
                    <div className="flex-1">
                      <p className="font-bold text-white">
                        {TRANSACTION_TYPE_LABELS[txn.type as keyof typeof TRANSACTION_TYPE_LABELS]}
                      </p>
                      <p className="text-xs text-muted-foreground">{txn.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">{txn.createdAt}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p
                      className={`font-bold font-mono text-lg ${
                        txn.type === 'earning' || txn.type === 'deposit'
                          ? 'text-green-400'
                          : 'text-red-400'
                      }`}
                    >
                      {txn.type === 'earning' || txn.type === 'deposit' ? '+' : '-'}₽{txn.amount.toLocaleString('ru-RU')}
                    </p>
                    <Badge className={`mt-2 ${getStatusColor(txn.status)} border`}>
                      {TRANSACTION_STATUS_LABELS[txn.status as keyof typeof TRANSACTION_STATUS_LABELS]}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
