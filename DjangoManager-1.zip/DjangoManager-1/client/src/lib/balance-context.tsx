import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_USER } from './mock-data';

interface BalanceContextType {
  balance: number;
  setBalance: (balance: number) => void;
  updateBalance: (amount: number) => void;
}

const BalanceContext = createContext<BalanceContextType | undefined>(undefined);

export function BalanceProvider({ children }: { children: React.ReactNode }) {
  const [balance, setBalance] = useState(INITIAL_USER.balance);

  // Poll for balance updates every 1 second
  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const res = await fetch(`/api/users/${INITIAL_USER.id}`);
        if (res.ok) {
          const user = await res.json();
          setBalance(parseFloat(user.balance) || INITIAL_USER.balance);
        }
      } catch (error) {
        console.error('Failed to fetch balance:', error);
      }
    };

    fetchBalance();
    const interval = setInterval(fetchBalance, 1000);
    return () => clearInterval(interval);
  }, []);

  const updateBalance = (amount: number) => {
    setBalance(prev => Math.max(0, prev + amount));
  };

  return (
    <BalanceContext.Provider value={{ balance, setBalance, updateBalance }}>
      {children}
    </BalanceContext.Provider>
  );
}

export function useBalance() {
  const context = useContext(BalanceContext);
  if (context === undefined) {
    throw new Error('useBalance must be used within BalanceProvider');
  }
  return context;
}
