import { useState } from "react";
import { Link } from "wouter";
import { Terminal, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/language-context";

const ADMIN_PASSWORD = "shoto095";

export default function CommandTerminal() {
  const [isOpen, setIsOpen] = useState(false);
  const [command, setCommand] = useState("");
  const [password, setPassword] = useState("");
  const [hasAccess, setHasAccess] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const { language } = useLanguage();

  const handleCommand = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      if (command.toLowerCase() === "admin" || command.toLowerCase() === "админ") {
        setShowPasswordPrompt(true);
        setCommand("");
        setAttempts(0);
      } else {
        setCommand("");
      }
    }
  };

  const handlePassword = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      if (password === ADMIN_PASSWORD) {
        localStorage.setItem("admin_access", "true");
        setHasAccess(true);
        setPassword("");
        setShowPasswordPrompt(false);
      } else {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        setPassword("");
        if (newAttempts >= 3) {
          setLocked(true);
          setTimeout(() => {
            setLocked(false);
            setAttempts(0);
            setShowPasswordPrompt(false);
          }, 5000);
        }
      }
    }
  };

  if (hasAccess) {
    return (
      <div className="w-full bg-black/40 border-b border-green-500/50 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400 font-mono">
            {language === 'ru' ? '✓ Панель администратора активна' : '✓ Admin panel active'}
          </span>
        </div>
        <Link href="/admin">
          <Button className="bg-green-600 hover:bg-green-700 text-xs h-7">
            {language === 'ru' ? 'Открыть' : 'Open'}
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      {isOpen && (
        <div className="w-full bg-black/50 border-b border-green-500/30 px-4 py-3">
          <div className="max-w-6xl mx-auto flex items-center gap-2">
            <Terminal className="w-4 h-4 text-green-400 flex-shrink-0" />
            {showPasswordPrompt ? (
              <>
                <div className="flex-1">
                  <Input
                    type="password"
                    placeholder={language === 'ru' ? 'Введите пароль...' : 'Enter password...'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyDown={handlePassword}
                    autoFocus
                    disabled={locked}
                    className={`bg-black/30 border-green-500/30 text-green-400 placeholder:text-green-600/50 h-9 font-mono text-sm ${
                      locked ? 'border-red-500/50 opacity-50' : ''
                    }`}
                  />
                  {attempts > 0 && !locked && (
                    <p className="text-xs text-red-400 mt-1">
                      {language === 'ru' 
                        ? `Неверный пароль. Попыток осталось: ${3 - attempts}`
                        : `Wrong password. Attempts left: ${3 - attempts}`}
                    </p>
                  )}
                  {locked && (
                    <p className="text-xs text-red-400 mt-1">
                      {language === 'ru' ? 'Доступ заблокирован на 5 секунд' : 'Access locked for 5 seconds'}
                    </p>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-green-400 hover:bg-green-500/10 h-9 w-9 flex-shrink-0"
                  onClick={() => {
                    setShowPasswordPrompt(false);
                    setPassword("");
                    setAttempts(0);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <>
                <Input
                  type="text"
                  placeholder={language === 'ru' ? 'Введите команду...' : 'Enter command...'}
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  onKeyDown={handleCommand}
                  autoFocus
                  className="bg-black/30 border-green-500/30 text-green-400 placeholder:text-green-600/50 h-9 font-mono text-sm"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-green-400 hover:bg-green-500/10 h-9 w-9 flex-shrink-0"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      )}
      {!isOpen && (
        <div className="w-full bg-black/20 border-b border-white/5 px-4 py-1 flex justify-center">
          <button
            onClick={() => setIsOpen(true)}
            className="text-xs text-muted-foreground hover:text-green-400 transition-colors font-mono"
          >
            [{language === 'ru' ? 'КОМАНДА' : 'COMMAND'}]
          </button>
        </div>
      )}
    </>
  );
}
