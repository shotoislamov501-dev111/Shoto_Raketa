import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { useBalance } from '@/lib/balance-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { GAME_CONFIG, INITIAL_USER } from '@/lib/mock-data';
import { Flame, Trophy, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function RocketGame() {
  const [status, setStatus] = useState<'idle' | 'flying' | 'crashed'>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [betAmount, setBetAmount] = useState(10);
  const [autoCashout, setAutoCashout] = useState<number | null>(null);
  const [rocketRotation, setRocketRotation] = useState(0);
  const [userId] = useState(INITIAL_USER.id);
  const canvasRef = useRef<HTMLDivElement>(null);
  const { t, language } = useLanguage();
  const { balance: userBalance, updateBalance } = useBalance();


  // Show loss notification when crashed
  useEffect(() => {
    if (status === 'crashed') {
      toast.error(language === 'ru' ? `✗ ПРОИГРЫШ! -₽${betAmount.toFixed(2)}` : `✗ LOSS! -₽${betAmount.toFixed(2)}`);
    }
  }, [status, betAmount, language]);

  // Game Loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (status === 'flying') {
      const startTime = Date.now();
      interval = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const newMultiplier = Math.max(1.00, 1.00 + (0.1 * elapsed * elapsed)); 
        
        setMultiplier(newMultiplier);
        setRocketRotation(elapsed * 15); // Rotate rocket as it flies

        if (Math.random() < 0.005 * newMultiplier) {
          setStatus('crashed');
          setRocketRotation(45); // Tip over when crashed
          clearInterval(interval);
        }
        
        if (autoCashout && newMultiplier >= autoCashout) {
            handleCashout();
            setStatus('idle');
        }

      }, 50);
    } else {
      setRocketRotation(0);
    }

    return () => clearInterval(interval);
  }, [status, autoCashout]);

  const handleStart = async () => {
    // Check balance
    if (userBalance < betAmount) {
      alert(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    // Deduct bet from balance immediately
    updateBalance(-betAmount);

    // Try to record transaction on server (non-blocking)
    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'rocket',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });
    } catch (error) {
      console.error('Failed to record bet:', error);
    }

    setStatus('flying');
    setMultiplier(1.00);
  };

  const handleCashout = async () => {
    const winAmount = betAmount * multiplier;
    
    // Add winnings to balance immediately
    updateBalance(winAmount);

    // Try to record win on server (non-blocking)
    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'rocket',
          betAmount: betAmount.toString(),
          winAmount: winAmount.toString(),
          multiplier: multiplier.toString(),
          status: 'win',
        }),
      });
    } catch (error) {
      console.error('Failed to record win:', error);
    }

    toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! +₽${winAmount.toFixed(2)}` : `✓ WIN! +₽${winAmount.toFixed(2)}`);
    setStatus('idle');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      {/* Game Display */}
      <div className="lg:col-span-2 relative h-[500px] glass-card rounded-2xl overflow-hidden flex flex-col p-1" style={{background: '#000000'}}>
        
        <div className="absolute inset-0 z-0">
          {/* Deep Space Background */}
          <div className="absolute inset-0 bg-black" />
          
          {/* Cosmic Stars - Small */}
          {[...Array(30)].map((_, i) => (
            <div
              key={`star-small-${i}`}
              className="absolute w-0.5 h-0.5 bg-white rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.8 + 0.2,
                animation: `twinkle ${Math.random() * 2 + 2}s infinite`,
              }}
            />
          ))}
          
          {/* Medium Stars */}
          {[...Array(15)].map((_, i) => (
            <div
              key={`star-medium-${i}`}
              className="absolute w-1 h-1 bg-cyan-200 rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.7 + 0.3,
                animation: `twinkle ${Math.random() * 3 + 3}s infinite`,
                boxShadow: `0 0 ${Math.random() * 4 + 2}px rgba(34, 211, 238, 0.6)`,
              }}
            />
          ))}
          
          {/* Large Colorful Stars */}
          <div className="absolute w-1.5 h-1.5 bg-blue-400 rounded-full top-12 left-12 opacity-70 animate-pulse" style={{boxShadow: '0 0 8px rgba(59, 130, 246, 0.8)'}} />
          <div className="absolute w-1 h-1 bg-purple-400 rounded-full top-1/4 right-20 opacity-60 animate-pulse" style={{boxShadow: '0 0 6px rgba(168, 85, 247, 0.7)'}} />
          <div className="absolute w-1.5 h-1.5 bg-cyan-300 rounded-full bottom-1/3 left-1/4 opacity-70" style={{animation: 'pulse 2.5s infinite', boxShadow: '0 0 8px rgba(34, 211, 238, 0.8)'}} />
          <div className="absolute w-1 h-1 bg-blue-300 rounded-full top-1/3 right-1/3 opacity-50" style={{animation: 'pulse 3.5s infinite'}} />
          <div className="absolute w-1.5 h-1.5 bg-violet-400 rounded-full bottom-20 right-1/4 opacity-60" style={{boxShadow: '0 0 8px rgba(139, 92, 246, 0.7)'}} />
          
          {/* Floating Asteroids */}
          <motion.div
            className="absolute w-2 h-2 bg-gray-400 rounded-full"
            style={{top: '15%', left: '10%', opacity: 0.4}}
            animate={{y: [0, 20, 0], x: [0, -10, 0]}}
            transition={{duration: 8, repeat: Infinity}}
          />
          <motion.div
            className="absolute w-1.5 h-1.5 bg-gray-500 rounded-full"
            style={{top: '70%', right: '15%', opacity: 0.3}}
            animate={{y: [0, -15, 0], x: [0, 15, 0]}}
            transition={{duration: 10, repeat: Infinity}}
          />
          <motion.div
            className="absolute w-1 h-1 bg-gray-400 rounded-full"
            style={{top: '40%', right: '5%', opacity: 0.35}}
            animate={{y: [0, 25, 0], x: [0, 20, 0]}}
            transition={{duration: 12, repeat: Infinity}}
          />
          
          {/* Grid Background - Speed based on multiplier */}
          <div 
            className="absolute inset-0 bg-[linear-gradient(rgba(34,211,238,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(34,211,238,0.05)_1px,transparent_1px)] bg-[size:50px_50px] opacity-30 origin-bottom"
            style={status === 'flying' ? {
              animation: `grid-scroll ${Math.max(0.5, 3 / multiplier)}s linear infinite`,
              transform: 'perspective(500px) rotateX(60deg)'
            } : {
              transform: 'perspective(500px) rotateX(60deg) translateY(0)'
            }}
          />
        </div>

        <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
          {status === 'crashed' ? (
            <div className="text-center animate-bounce">
              <h1 className="text-6xl font-black text-red-500 font-orbitron drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]">
                {t('crashed')}
              </h1>
              <p className="text-xl text-cyan-300 mt-2">{t('atMultiplier')}{multiplier.toFixed(2)}x</p>
            </div>
          ) : (
            <div className="text-center">
              <h1 className={`text-7xl font-black font-orbitron tabular-nums transition-colors duration-200 ${
                status === 'flying' ? 'text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 drop-shadow-[0_0_30px_rgba(34,211,238,0.6)]' : 'text-white/30'
              }`}>
                {multiplier.toFixed(2)}x
              </h1>
              {status === 'flying' && (
                <p className="text-cyan-300 font-bold mt-2 animate-pulse">{t('currentWin')}₽{(betAmount * multiplier).toFixed(2)}</p>
              )}
            </div>
          )}
        </div>

        <div className="relative flex-1 z-10 overflow-hidden" ref={canvasRef}>
          <AnimatePresence>
            {status !== 'crashed' && (
              <motion.div
                className="absolute left-1/2 -translate-x-1/2 bottom-20"
                initial={{ y: 0 }}
                animate={
                  status === 'flying' 
                    ? { 
                        y: [0, -2, 2, -1, 0],
                        x: [-1, 1, -1, 0],
                      }
                    : { y: 0 }
                }
                transition={{ repeat: Infinity, duration: 0.2 }}
              >
                {/* Rocket Glow Aura */}
                {status === 'flying' && (
                  <div className="absolute inset-0 w-32 h-48 -left-4 -top-4 z-0">
                    <motion.div
                      animate={{
                        opacity: [0.4, 0.7, 0.4],
                        scale: [0.9, 1.3, 0.9],
                      }}
                      transition={{ repeat: Infinity, duration: 0.8 }}
                      className="w-full h-full bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-full blur-3xl"
                    />
                  </div>
                )}

                <div className={`relative w-32 h-48 transition-transform duration-100 ${status === 'flying' ? '-translate-y-24' : ''}`} style={{ transform: `perspective(1000px) rotateZ(${rocketRotation * 0.3}deg)` }}>
                  
                  {/* Rocket Trail Particles */}
                  {status === 'flying' && (
                    <div className="absolute inset-0 pointer-events-none">
                      {[...Array(3)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="absolute w-2 h-2 rounded-full"
                          style={{
                            left: '50%',
                            bottom: `${-20 - i * 15}px`,
                            background: ['#ff6b6b', '#ff9ff3', '#ffd93d'][i],
                            boxShadow: `0 0 ${8 + i * 4}px ${['#ff6b6b', '#ff9ff3', '#ffd93d'][i]}`,
                          }}
                          animate={{
                            y: [0, -30, -60],
                            opacity: [1, 0.5, 0],
                            scale: [1, 0.8, 0.5],
                          }}
                          transition={{ duration: 0.6, delay: i * 0.1, repeat: Infinity }}
                        />
                      ))}
                    </div>
                  )}

                  <svg viewBox="0 0 50 160" fill="none" className="w-full h-full drop-shadow-[0_0_60px_rgba(34,211,238,0.8)]">
                    <defs>
                      <radialGradient id="rocketShine" cx="40%" cy="30%">
                        <stop offset="0%" style={{ stopColor: '#ffffff', stopOpacity: 0.4 }} />
                        <stop offset="50%" style={{ stopColor: '#00d9ff', stopOpacity: 0.6 }} />
                        <stop offset="100%" style={{ stopColor: '#0284c7', stopOpacity: 1 }} />
                      </radialGradient>
                      <linearGradient id="coneGrad" x1="50%" y1="0%" x2="50%" y2="100%">
                        <stop offset="0%" style={{ stopColor: '#00ffff', stopOpacity: 1 }} />
                        <stop offset="50%" style={{ stopColor: '#06b6d4', stopOpacity: 1 }} />
                        <stop offset="100%" style={{ stopColor: '#0284c7', stopOpacity: 1 }} />
                      </linearGradient>
                      <filter id="glowCyan">
                        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                        <feMerge>
                          <feMergeNode in="coloredBlur"/>
                          <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                      </filter>
                    </defs>
                    
                    {/* Nose Cone - Bright Cyan */}
                    <path d="M25 2 L38 35 L12 35 Z" fill="url(#coneGrad)" stroke="#00ffff" strokeWidth="1.5" filter="url(#glowCyan)"/>
                    <path d="M25 2 L38 35 L12 35 Z" fill="none" stroke="#00d9ff" strokeWidth="0.8" opacity="0.6"/>
                    
                    {/* Main Body - Metallic Cylinder */}
                    <rect x="14" y="35" width="22" height="95" fill="url(#rocketShine)" stroke="#00d9ff" strokeWidth="2" filter="url(#glowCyan)"/>
                    
                    {/* Body Shine Line */}
                    <line x1="18" y1="35" x2="18" y2="130" stroke="#ffffff" strokeWidth="1.5" opacity="0.4" filter="url(#glowCyan)"/>
                    
                    {/* Top Window - Cockpit */}
                    <circle cx="25" cy="52" r="7" fill="#e0f2fe" stroke="#00ffff" strokeWidth="1.5" filter="url(#glowCyan)"/>
                    <circle cx="25" cy="52" r="5" fill="#67e8f9" opacity="0.7"/>
                    <circle cx="25" cy="52" r="2" fill="#ffffff" opacity="0.8"/>
                    
                    {/* Energy Reactor Bands */}
                    <rect x="12" y="70" width="26" height="3" fill="#00ffff" opacity="0.8" filter="url(#glowCyan)"/>
                    <rect x="12" y="70" width="26" height="1" fill="#ffffff" opacity="0.5"/>
                    
                    <rect x="12" y="92" width="26" height="2.5" fill="#00d9ff" opacity="0.7" filter="url(#glowCyan)"/>
                    
                    <rect x="12" y="112" width="26" height="2.5" fill="#00d9ff" opacity="0.6" filter="url(#glowCyan)"/>
                    
                    {/* Left Stabilizer Fin - Enhanced */}
                    <path d="M14 85 L-5 125 L10 115 Z" fill="#0284c7" stroke="#00d9ff" strokeWidth="1.2" opacity="0.9" filter="url(#glowCyan)"/>
                    <path d="M14 85 L-5 125 L10 115 Z" fill="none" stroke="#00ffff" strokeWidth="0.6" opacity="0.5"/>
                    
                    {/* Right Stabilizer Fin - Enhanced */}
                    <path d="M36 85 L55 125 L40 115 Z" fill="#0284c7" stroke="#00d9ff" strokeWidth="1.2" opacity="0.9" filter="url(#glowCyan)"/>
                    <path d="M36 85 L55 125 L40 115 Z" fill="none" stroke="#00ffff" strokeWidth="0.6" opacity="0.5"/>
                    
                    {/* Bottom Vector Fins - Enhanced */}
                    <path d="M25 125 L25 148 L20 135 Z" fill="#00d9ff" stroke="#00ffff" strokeWidth="1" opacity="0.9" filter="url(#glowCyan)"/>
                    <path d="M25 125 L25 148 L30 135 Z" fill="#00d9ff" stroke="#00ffff" strokeWidth="1" opacity="0.9" filter="url(#glowCyan)"/>
                    
                    {/* Engine Bell */}
                    <circle cx="25" cy="145" r="8" fill="none" stroke="#0284c7" strokeWidth="2" opacity="0.8" filter="url(#glowCyan)"/>
                    <circle cx="25" cy="145" r="8" fill="none" stroke="#00ffff" strokeWidth="0.8" opacity="0.5"/>
                    
                    {/* Engine Core Glow */}
                    <ellipse cx="25" cy="148" rx="6" ry="3" fill="#00ffff" opacity="0.7" filter="url(#glowCyan)"/>
                    <ellipse cx="25" cy="148" rx="3" ry="1.5" fill="#ffffff" opacity="0.6"/>
                  </svg>
                  
                  {/* Plasma Thrust Animation */}
                  {status === 'flying' && (
                    <div className="absolute top-full left-1/2 -translate-x-1/2 w-24 -mt-1 pointer-events-none">
                      {/* Plasma Core */}
                      <motion.div
                        animate={{
                          height: [70, 130, 85],
                          opacity: [1, 0.9, 1],
                          scaleX: [0.7, 1.15, 0.8],
                        }}
                        transition={{ repeat: Infinity, duration: 0.07 }}
                        className="w-full bg-gradient-to-b from-cyan-300 via-cyan-400 to-blue-600 rounded-full blur-lg"
                        style={{ boxShadow: '0 0 50px rgba(34, 211, 238, 0.9), 0 0 80px rgba(59, 130, 246, 0.6)' }}
                      />
                      
                      {/* Plasma Tendrils Left */}
                      <motion.div
                        animate={{
                          height: [65, 125, 75],
                          opacity: [0.8, 0.4, 0.8],
                          x: [-16, -6, -16],
                        }}
                        transition={{ repeat: Infinity, duration: 0.09, delay: 0.01 }}
                        className="absolute top-0 left-1/2 w-16 bg-gradient-to-b from-cyan-400 via-blue-500 to-transparent rounded-full blur-2xl"
                      />
                      
                      {/* Plasma Tendrils Right */}
                      <motion.div
                        animate={{
                          height: [65, 125, 75],
                          opacity: [0.8, 0.4, 0.8],
                          x: [16, 6, 16],
                        }}
                        transition={{ repeat: Infinity, duration: 0.09, delay: 0.01 }}
                        className="absolute top-0 left-1/2 w-16 bg-gradient-to-b from-cyan-400 via-blue-500 to-transparent rounded-full blur-2xl"
                      />
                      
                      {/* Outer Energy Field */}
                      <motion.div
                        animate={{
                          height: [55, 110, 65],
                          opacity: [0.6, 0.25, 0.6],
                        }}
                        transition={{ repeat: Infinity, duration: 0.1, delay: 0.03 }}
                        className="absolute top-0 left-1/2 -translate-x-1/2 w-36 bg-gradient-to-b from-cyan-300 to-transparent rounded-full blur-3xl"
                      />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Controls */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between h-[500px]">
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold font-orbitron text-white">{t('controls')}</h2>
              <div className="mt-2 px-3 py-2 bg-gradient-to-r from-green-600/30 to-emerald-600/30 border border-green-500/50 rounded-lg">
                <p className="text-lg font-bold font-mono text-transparent bg-clip-text bg-gradient-to-r from-green-300 to-emerald-300 drop-shadow-[0_0_8px_rgba(16,185,129,0.6)]">₽{userBalance.toFixed(2)}</p>
              </div>
            </div>
            <div className="flex items-center text-xs text-muted-foreground gap-1">
              <AlertTriangle className="w-3 h-3" />
              <span>{t('highRisk')}</span>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('betAmount')}</span>
              <span className="text-white font-bold">₽{betAmount}</span>
            </div>
            <div className="flex gap-2">
               <Button 
                 variant="outline" 
                 className="flex-1 bg-white/5 border-white/10 hover:bg-white/10 text-xs"
                 onClick={() => setBetAmount(Math.max(GAME_CONFIG.minBet, betAmount / 2))}
                 disabled={status === 'flying'}
               >
                 ½
               </Button>
               <Button 
                 variant="outline" 
                 className="flex-1 bg-white/5 border-white/10 hover:bg-white/10 text-xs"
                 onClick={() => setBetAmount(betAmount * 2)}
                 disabled={status === 'flying'}
               >
                 2x
               </Button>
               <Button 
                 variant="outline" 
                 className="flex-1 bg-white/5 border-white/10 hover:bg-white/10 text-xs"
                 onClick={() => setBetAmount(GAME_CONFIG.maxBet)}
                 disabled={status === 'flying'}
               >
                 {t('max')}
               </Button>
            </div>
            <div className="relative">
              <Input 
                type="number" 
                value={betAmount} 
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="h-14 text-lg font-mono bg-black/30 border-white/20 focus:border-primary text-center"
                disabled={status === 'flying'}
              />
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('autoCashout')}</span>
              <span className="text-white font-bold">{autoCashout || 'ВЫКЛ'}</span>
            </div>
             <Input 
                type="number" 
                placeholder="2.00"
                value={autoCashout || ''} 
                onChange={(e) => setAutoCashout(e.target.value ? Number(e.target.value) : null)}
                className="h-12 font-mono bg-black/30 border-white/20 text-center"
                disabled={status === 'flying'}
              />
          </div>
        </div>

        <Button 
          size="lg"
          className={`w-full h-20 text-xl font-black font-orbitron uppercase tracking-widest transition-all duration-200 flex flex-col items-center justify-center ${
            status === 'flying' 
              ? 'bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 shadow-[0_0_30px_rgba(34,211,238,0.5)]' 
              : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-[0_0_30px_rgba(16,185,129,0.4)]'
          }`}
          onClick={status === 'flying' ? handleCashout : handleStart}
          disabled={status === 'crashed'}
        >
          {status === 'flying' ? (
            <>
              <span>{language === 'ru' ? 'ЗАБРАТЬ' : 'TAKE'}</span>
              <span className="text-sm">₽{(betAmount * multiplier).toFixed(2)}</span>
            </>
          ) : status === 'crashed' ? (
            t('again')
          ) : (
            t('launch')
          )}
        </Button>
        
        {status === 'crashed' && (
           <Button 
             variant="ghost" 
             className="w-full mt-4 text-white/50 hover:text-white"
             onClick={() => setStatus('idle')}
           >
             {t('reset')}
           </Button>
        )}
      </div>
    </div>
  );
}
