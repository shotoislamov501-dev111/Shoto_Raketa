import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Rocket, Wallet, User as UserIcon, LogOut, Menu, Globe, MessageCircle } from "lucide-react";
import { INITIAL_USER } from "@/lib/mock-data";
import { useLanguage } from "@/lib/language-context";
import { useBalance } from "@/lib/balance-context";
import { Language } from "@/lib/translations";
import { Button } from "@/components/ui/button";
import CommandTerminal from "@/components/command-terminal";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState(INITIAL_USER);
  const [location] = useLocation();
  const isAuthPage = location === "/auth";
  const { language, setLanguage, t } = useLanguage();
  const { balance } = useBalance();

  const handleLogout = () => {
    setUser(null as any);
  };

  if (isAuthPage) {
    return <div className="min-h-screen flex items-center justify-center p-4">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Command Terminal */}
      <CommandTerminal />
      
      {/* Navigation */}
      <header className="sticky top-0 z-50 glass-panel border-b border-white/10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo with Telegram Support */}
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 group cursor-pointer">
                <div className="relative">
                  <Rocket className="w-8 h-8 text-secondary group-hover:animate-pulse transition-colors" />
                  <div className="absolute inset-0 bg-secondary/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <span className="text-2xl font-bold font-orbitron tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70 neon-text">
                  SHOTO
                </span>
            </Link>
            
            {/* Telegram Support Button */}
            <a
              href="https://t.me/shoto72773"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:flex items-center gap-2 px-3 py-2 rounded-full bg-sky-600/10 border border-sky-500/20 hover:border-sky-500/50 hover:bg-sky-600/20 transition-all group cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-sky-400 group-hover:text-sky-300 transition-colors" />
              <span className="text-xs font-bold text-sky-400 group-hover:text-sky-300 transition-colors">@shoto72773</span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            {/* Language Switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 text-white hover:bg-white/10">
                  <Globe className="w-4 h-4" />
                  <span className="font-bold">{language.toUpperCase()}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="glass-panel border-white/10 text-white bg-black/80">
                <DropdownMenuItem 
                  onClick={() => setLanguage('en')}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  English
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('ru')}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  Русский
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {user ? (
              <>
                <Link href="/withdrawal">
                  <div className="flex items-center gap-2 bg-black/20 px-4 py-2 rounded-full border border-white/5 hover:border-green-500/50 hover:bg-black/40 cursor-pointer transition-all group">
                    <Wallet className="w-4 h-4 text-primary group-hover:text-green-400 transition-colors" />
                    <span className="font-mono font-bold text-green-400 group-hover:text-green-300 transition-colors">
                      ₽{balance.toLocaleString('ru-RU')}
                    </span>
                  </div>
                </Link>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0 hover:bg-white/10">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-white" />
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 glass-panel border-white/10 text-white bg-black/80">
                    <DropdownMenuLabel>{user.username}</DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-white/10" />
                    <Link href="/profile">
                      <DropdownMenuItem className="hover:bg-white/10 cursor-pointer">
                        {t('profile')}
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/deposit">
                      <DropdownMenuItem className="hover:bg-white/10 cursor-pointer">
                        {language === 'ru' ? 'Пополнить' : 'Deposit'}
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/withdrawal">
                      <DropdownMenuItem className="hover:bg-white/10 cursor-pointer">
                        {t('withdraw')}
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/referral">
                      <DropdownMenuItem className="hover:bg-white/10 cursor-pointer">
                        {language === 'ru' ? 'Рефералы' : 'Referral'}
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuItem className="hover:bg-white/10 cursor-pointer">
                      {t('transactions')}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/10" />
                    <DropdownMenuItem 
                      className="text-red-400 hover:bg-red-500/10 cursor-pointer"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      {t('logout')}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex gap-2">
                <Link href="/auth">
                  <Button variant="ghost" className="text-white hover:bg-white/10 cursor-pointer">{t('login')}</Button>
                </Link>
                <Link href="/auth">
                  <Button className="bg-primary hover:bg-primary/90 text-white cursor-pointer">{t('register')}</Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu */}
          <div className="md:hidden flex items-center gap-2">
            {/* Mobile Language Switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <Globe className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="glass-panel border-white/10 text-white bg-black/80">
                <DropdownMenuItem 
                  onClick={() => setLanguage('en')}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  English
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('ru')}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  Русский
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent className="glass-panel border-l-white/10 text-white w-64 bg-black/90">
                <div className="flex flex-col gap-4 mt-8">
                  {user ? (
                    <>
                      <Link href="/withdrawal">
                        <div className="flex items-center gap-3 p-2 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-all">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center">
                            <UserIcon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <p className="font-bold">{user.username}</p>
                            <p className="text-green-400 font-mono hover:text-green-300 transition-colors">₽{user.balance.toLocaleString('ru-RU')}</p>
                          </div>
                        </div>
                      </Link>
                      <Link href="/profile">
                        <Button variant="ghost" className="justify-start w-full text-left">{t('profile')}</Button>
                      </Link>
                      <Link href="/deposit">
                        <Button variant="ghost" className="justify-start w-full text-left">{language === 'ru' ? 'Пополнить' : 'Deposit'}</Button>
                      </Link>
                      <Link href="/withdrawal">
                        <Button variant="ghost" className="justify-start w-full text-left">{t('withdraw')}</Button>
                      </Link>
                      <Link href="/referral">
                        <Button variant="ghost" className="justify-start w-full text-left">{language === 'ru' ? 'Рефералы' : 'Referral'}</Button>
                      </Link>
                      <Button variant="ghost" className="justify-start">{t('transactions')}</Button>
                      <Button 
                        variant="destructive" 
                        className="justify-start"
                        onClick={handleLogout}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        {t('logout')}
                      </Button>
                    </>
                  ) : (
                    <div className="flex flex-col gap-2">
                      <Link href="/auth">
                        <Button className="w-full bg-primary">{t('login')} / {t('register')}</Button>
                      </Link>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className="glass-panel border-t border-white/10 mt-auto">
        <div className="container mx-auto px-4 py-8 text-center text-muted-foreground text-sm">
          <p>© 2024 SHOTO Gaming Platform. All rights reserved.</p>
          <div className="flex justify-center gap-4 mt-4">
            <a href="#" className="hover:text-white transition-colors">{language === 'ru' ? 'Условия' : 'Terms'}</a>
            <a href="#" className="hover:text-white transition-colors">{language === 'ru' ? 'Конфиденциальность' : 'Privacy'}</a>
            <a href="#" className="hover:text-white transition-colors">{language === 'ru' ? 'Поддержка' : 'Support'}</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
