import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { GAME_CONFIG, INITIAL_USER } from '@/lib/mock-data';
import { Bomb, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface Cell {
  id: number;
  isBomb: boolean;
  isRevealed: boolean;
  row: number;
  col: number;
}

const GRID_SIZE = 5;
const BOMB_COUNT = 5;
const BASE_MULTIPLIER = 0.1;

export default function BomberGame() {
  const [grid, setGrid] = useState<Cell[]>([]);
  const [status, setStatus] = useState<'idle' | 'playing' | 'lost' | 'won'>('idle');
  const [revealedCount, setRevealedCount] = useState(0);
  const [betAmount, setBetAmount] = useState(10);
  const [gameMultiplier, setGameMultiplier] = useState(1.0);
  const [userBalance, setUserBalance] = useState(INITIAL_USER.balance);
  const [userId] = useState(INITIAL_USER.id);
  const [gameTransactionId, setGameTransactionId] = useState<string | null>(null);
  const { t, language } = useLanguage();

  useEffect(() => {
    const fetchUserBalance = async () => {
      try {
        const res = await fetch(`/api/users/${userId}`);
        if (res.ok) {
          const user = await res.json();
          setUserBalance(parseFloat(user.balance));
        }
      } catch (error) {
        console.error('Failed to fetch user balance:', error);
      }
    };
    fetchUserBalance();
    
    // Refresh balance every 2 seconds
    const interval = setInterval(fetchUserBalance, 2000);
    return () => clearInterval(interval);
  }, [userId]);

  // Show loss notification when hit bomb
  useEffect(() => {
    if (status === 'lost') {
      toast.error(language === 'ru' ? `✗ ПРОИГРЫШ! -₽${betAmount.toFixed(2)}` : `✗ LOSS! -₽${betAmount.toFixed(2)}`);
    }
  }, [status, betAmount, language]);

  const initializeGame = async () => {
    // Check balance
    if (userBalance < betAmount) {
      alert(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    // Deduct bet from balance immediately (client-side)
    setUserBalance(prev => prev - betAmount);

    // Try to record transaction on server (non-blocking, errors are logged)
    try {
      const res = await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'bomber',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });

      if (res.ok) {
        const transaction = await res.json();
        setGameTransactionId(transaction.id);
      }
    } catch (error) {
      console.error('Failed to record bet:', error);
      // Continue game even if server transaction fails
    }

    const newGrid: Cell[] = [];
    const bombPositions = new Set<number>();
    
    while (bombPositions.size < BOMB_COUNT) {
      bombPositions.add(Math.floor(Math.random() * (GRID_SIZE * GRID_SIZE)));
    }

    for (let i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
      newGrid.push({
        id: i,
        isBomb: bombPositions.has(i),
        isRevealed: false,
        row: Math.floor(i / GRID_SIZE),
        col: i % GRID_SIZE,
      });
    }

    setGrid(newGrid);
    setStatus('playing');
    setRevealedCount(0);
    setGameMultiplier(1.0);
  };

  const handleCellClick = (cellId: number) => {
    if (status !== 'playing') return;

    const newGrid = [...grid];
    const cell = newGrid[cellId];

    if (cell.isRevealed) return;

    cell.isRevealed = true;

    if (cell.isBomb) {
      setStatus('lost');
      setGrid(newGrid);
      return;
    }

    const newRevealedCount = newGrid.filter((c) => c.isRevealed && !c.isBomb).length;
    const newMultiplier = 1.0 + newRevealedCount * BASE_MULTIPLIER;

    setGrid(newGrid);
    setRevealedCount(newRevealedCount);
    setGameMultiplier(newMultiplier);

    if (newRevealedCount === GRID_SIZE * GRID_SIZE - BOMB_COUNT) {
      setStatus('won');
    }
  };

  const handleCashout = async () => {
    if (status === 'playing' || status === 'won') {
      const winAmount = betAmount * gameMultiplier;
      
      // Add winnings to balance immediately
      setUserBalance(prev => prev + winAmount);
      
      // Try to record win on server (non-blocking)
      try {
        await fetch(`/api/game-transactions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            game: 'bomber',
            betAmount: betAmount.toString(),
            winAmount: winAmount.toString(),
            multiplier: gameMultiplier.toString(),
            status: 'win',
          }),
        });
      } catch (error) {
        console.error('Failed to record win:', error);
      }
      
      toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! +₽${winAmount.toFixed(2)}` : `✓ WIN! +₽${winAmount.toFixed(2)}`);
      setStatus('idle');
      setGameTransactionId(null);
    }
  };

  const handleRestart = async () => {
    setStatus('idle');
    setGrid([]);
    setRevealedCount(0);
    setGameMultiplier(1.0);
    setGameTransactionId(null);
  };

  const getStatusMessage = () => {
    if (status === 'lost') return language === 'ru' ? 'ВЗРЫВ!' : 'BOMBED!';
    if (status === 'won') return language === 'ru' ? 'ПОБЕДА!' : 'VICTORY!';
    return null;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      <div className="lg:col-span-2 relative min-h-[500px] glass-card rounded-2xl overflow-hidden flex flex-col p-6">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#2a1810] to-[#0a0505] z-0" />

        <div className="relative z-10 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className={`text-5xl font-black font-orbitron transition-colors ${
                status === 'playing' 
                  ? 'text-white drop-shadow-[0_0_20px_rgba(255,120,0,0.8)]' 
                  : 'text-white/50'
              }`}>
                {gameMultiplier.toFixed(2)}x
              </h1>
              {status === 'playing' && (
                <p className="text-green-400 font-bold text-sm mt-1">
                  {language === 'ru' ? 'Выигрыш' : 'Win'}: ₽{(betAmount * gameMultiplier).toFixed(2)}
                </p>
              )}
            </div>
            <div className="text-right">
              <p className="text-muted-foreground text-sm">{language === 'ru' ? 'Открыто' : 'Revealed'}</p>
              <p className="text-2xl font-bold text-white">{revealedCount}/{GRID_SIZE * GRID_SIZE - BOMB_COUNT}</p>
            </div>
          </div>

          {getStatusMessage() && (
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.5 }}
              className={`text-center text-4xl font-black font-orbitron drop-shadow-lg ${
                status === 'lost' ? 'text-red-500' : 'text-yellow-400'
              }`}
            >
              {getStatusMessage()}
            </motion.div>
          )}
        </div>

        {status !== 'idle' && grid.length > 0 && (
          <div className="relative z-10 flex-1 flex items-center justify-center">
            <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))` }}>
              {grid.map((cell) => (
                <motion.button
                  key={cell.id}
                  whileHover={status === 'playing' && !cell.isRevealed ? { scale: 1.05 } : {}}
                  whileTap={status === 'playing' && !cell.isRevealed ? { scale: 0.95 } : {}}
                  onClick={() => handleCellClick(cell.id)}
                  disabled={status !== 'playing' || cell.isRevealed}
                  className={`w-16 h-16 rounded-lg font-black text-2xl transition-all duration-200 border-2 ${
                    cell.isRevealed
                      ? cell.isBomb
                        ? 'bg-red-600/40 border-red-500 text-red-400 cursor-not-allowed drop-shadow-[0_0_15px_rgba(255,0,0,0.5)]'
                        : 'bg-yellow-500/30 border-yellow-400 text-yellow-300 cursor-not-allowed drop-shadow-[0_0_15px_rgba(255,200,0,0.4)]'
                      : 'bg-orange-600/40 border-orange-400 hover:bg-orange-500/50 hover:border-orange-300 cursor-pointer drop-shadow-[0_0_10px_rgba(255,120,0,0.3)] hover:drop-shadow-[0_0_20px_rgba(255,120,0,0.6)]'
                  }`}
                >
                  {cell.isRevealed ? (
                    cell.isBomb ? (
                      <Bomb className="w-8 h-8 mx-auto" />
                    ) : (
                      '✓'
                    )
                  ) : (
                    '?'
                  )}
                </motion.button>
              ))}
            </div>
          </div>
        )}

        {status === 'idle' && (
          <div className="relative z-10 flex-1 flex items-center justify-center">
            <div className="text-center">
              <Bomb className="w-20 h-20 mx-auto text-red-500 mb-4 drop-shadow-[0_0_30px_rgba(255,50,0,0.6)]" />
              <h2 className="text-3xl font-bold font-orbitron text-orange-400 mb-2 drop-shadow-[0_0_15px_rgba(255,120,0,0.6)]">BOMBER</h2>
              <p className="text-muted-foreground mb-6">
                {language === 'ru' ? 'Откройте клетки, избегайте бомб' : 'Reveal cells, avoid bombs'}
              </p>
              <Button
                size="lg"
                className="bg-orange-600 hover:bg-orange-700 text-white drop-shadow-[0_0_20px_rgba(255,120,0,0.5)]"
                onClick={() => initializeGame()}
              >
                {language === 'ru' ? 'Начать игру' : 'Start Game'}
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between min-h-[500px] bg-gradient-to-b from-orange-950/20 to-orange-950/5 border border-orange-500/20">
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold font-orbitron text-orange-400 drop-shadow-[0_0_10px_rgba(255,120,0,0.5)]">
                {language === 'ru' ? 'ПАРАМЕТРЫ' : 'SETTINGS'}
              </h2>
              <p className="text-sm text-green-400 font-mono mt-1">₽{userBalance.toFixed(2)}</p>
            </div>
            <div className="flex items-center text-xs gap-1 text-red-400">
              <AlertTriangle className="w-3 h-3" />
              <span>{language === 'ru' ? 'РИСК' : 'HIGH RISK'}</span>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{language === 'ru' ? 'Ставка' : 'Bet'}</span>
              <span className="text-white font-bold">₽{betAmount}</span>
            </div>
            <div className="flex gap-2">
               <Button 
                 variant="outline" 
                 className="flex-1 bg-orange-600/30 border-orange-500/50 hover:bg-orange-600/50 text-xs text-orange-300"
                 onClick={() => setBetAmount(Math.max(GAME_CONFIG.minBet, betAmount / 2))}
                 disabled={status !== 'idle'}
               >
                 ½
               </Button>
               <Button 
                 variant="outline" 
                 className="flex-1 bg-orange-600/30 border-orange-500/50 hover:bg-orange-600/50 text-xs text-orange-300"
                 onClick={() => setBetAmount(betAmount * 2)}
                 disabled={status !== 'idle'}
               >
                 2x
               </Button>
               <Button 
                 variant="outline" 
                 className="flex-1 bg-orange-600/30 border-orange-500/50 hover:bg-orange-600/50 text-xs text-orange-300"
                 onClick={() => setBetAmount(GAME_CONFIG.maxBet)}
                 disabled={status !== 'idle'}
               >
                 MAX
               </Button>
            </div>
            <Input 
              type="number" 
              value={betAmount} 
              onChange={(e) => setBetAmount(Number(e.target.value))}
              className="h-14 text-lg font-mono bg-black/30 border-white/20 focus:border-primary text-center"
              disabled={status !== 'idle'}
            />
          </div>

          <div className="space-y-3 text-xs text-muted-foreground">
            <div className="flex justify-between">
              <span>{language === 'ru' ? 'Бомб на сетке' : 'Bombs on grid'}</span>
              <span className="text-white">{BOMB_COUNT}</span>
            </div>
            <div className="flex justify-between">
              <span>{language === 'ru' ? 'Безопасных клеток' : 'Safe cells'}</span>
              <span className="text-white">{GRID_SIZE * GRID_SIZE - BOMB_COUNT}</span>
            </div>
            <div className="flex justify-between">
              <span>{language === 'ru' ? 'Множитель за клетку' : 'Per cell'}</span>
              <span className="text-white">+{(BASE_MULTIPLIER * 100).toFixed(0)}%</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          {status === 'playing' && (
            <Button 
              size="lg"
              className="w-full h-14 text-lg font-black font-orbitron uppercase bg-green-600 hover:bg-green-700 shadow-[0_0_30px_rgba(34,197,94,0.4)]"
              onClick={handleCashout}
            >
              <div className="text-center">
                <div>{language === 'ru' ? 'Забрать' : 'Take'}</div>
                <div className="text-sm">₽{(betAmount * gameMultiplier).toFixed(2)}</div>
              </div>
            </Button>
          )}
          
          {(status === 'lost' || status === 'won') && (
            <Button 
              size="lg"
              className="w-full h-14 text-xl font-black font-orbitron uppercase bg-orange-600 hover:bg-orange-700"
              onClick={handleRestart}
            >
              {language === 'ru' ? 'Новая игра' : 'New Game'}
            </Button>
          )}
          
          {status === 'idle' && (
            <Button 
              size="lg"
              className="w-full h-14 text-xl font-black font-orbitron uppercase bg-orange-600 hover:bg-orange-700 shadow-[0_0_30px_rgba(249,115,22,0.4)]"
              onClick={() => initializeGame()}
            >
              {language === 'ru' ? 'Начать' : 'Play'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
