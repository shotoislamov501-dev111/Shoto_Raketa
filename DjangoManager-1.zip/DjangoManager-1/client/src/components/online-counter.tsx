import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users } from 'lucide-react';

export default function OnlineCounter() {
  const [onlineCount, setOnlineCount] = useState(300);
  const [displayCount, setDisplayCount] = useState(300);

  // Update online count every 2-5 seconds
  useEffect(() => {
    const updateInterval = setInterval(() => {
      setOnlineCount(prev => {
        // Random change between -20 and +30
        const change = Math.floor(Math.random() * 50) - 20;
        const newCount = Math.max(100, Math.min(500, prev + change));
        return newCount;
      });
    }, 2000 + Math.random() * 3000);

    return () => clearInterval(updateInterval);
  }, []);

  // Animate the display number to match the actual count
  useEffect(() => {
    let animationFrame: number;
    let currentDisplay = displayCount;
    
    const animate = () => {
      const diff = onlineCount - currentDisplay;
      if (Math.abs(diff) > 0) {
        currentDisplay += Math.sign(diff) * Math.ceil(Math.abs(diff) / 5);
        setDisplayCount(Math.round(currentDisplay));
        animationFrame = requestAnimationFrame(animate);
      }
    };

    if (displayCount !== onlineCount) {
      animationFrame = requestAnimationFrame(animate);
    }

    return () => cancelAnimationFrame(animationFrame);
  }, [onlineCount, displayCount]);

  return (
    <div className="glass-panel p-4 rounded-xl mb-6 flex items-center justify-between border border-green-500/30 bg-green-500/10">
      <div className="flex items-center gap-3">
        <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
        <div>
          <p className="text-sm text-muted-foreground">Игроков онлайн</p>
          <p className="font-bold text-white font-mono">
            {displayCount.toLocaleString('ru-RU')} / 500
          </p>
        </div>
      </div>
      <Users className="w-5 h-5 text-green-400" />
    </div>
  );
}
